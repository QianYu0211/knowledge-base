malloc_no_free\segger_rtt.o: ..\Middlewares\Third_Party\SEGGER_RTT\RTT\SEGGER_RTT.c
malloc_no_free\segger_rtt.o: ..\Middlewares\Third_Party\SEGGER_RTT\RTT\SEGGER_RTT.h
malloc_no_free\segger_rtt.o: ../Middlewares/Third_Party/SEGGER_RTT/Config/SEGGER_RTT_Conf.h
malloc_no_free\segger_rtt.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdlib.h
malloc_no_free\segger_rtt.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdarg.h
malloc_no_free\segger_rtt.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\stdint.h
malloc_no_free\segger_rtt.o: C:\Keil_v5\ARM\ARMCC\Bin\..\include\string.h
