#include "FreeRTOS.h"
#include "task.h"
#include "cmsis_os.h"
#include "user_rtt_printf.h"

static TaskHandle_t taskHandleA;

static TaskHandle_t printTaskHandle;

void creat_buffer_no_free(uint32_t size)
{
    uint8_t *pbuffer = NULL;

    pbuffer = pvPortMalloc(size);

    // vPortFree(pbuffer);

    return;
}

static void taskFunctionA(void *arg)
{
    vTaskDelay(2000);

    LOG("*************************\r\n");
    LOG("Now exit task.\r\n");
    LOG("*************************\r\n");

    creat_buffer_no_free(100);

    while (1)
    {
        LOG("Task A running...\r\n");

        vTaskDelay(5000);
    }
}

static void showTaskInformation(void *args)
{
    BaseType_t val;

    char pcWriteBuffer[200] = {0};

    for (int i = 0; i < 10; i++)
    {
        vTaskList(pcWriteBuffer);
        LOG("[loop:%d, tick:xx.]-----------------------------------------\r\n", i);
        LOG("Name    State   Priority    Stack   Num\r\n");
        LOG("%s\r\n", pcWriteBuffer);

        /* 查询系统历史剩余最小内存 */
        LOG("Total FreeRTOS memory size: %d bytes.\r\n", configTOTAL_HEAP_SIZE);                               // 打印FreeRTOS总内存大小（单位字节）
        LOG("The current remaining heap memory size is: %d bytes.\r\n", xPortGetFreeHeapSize());               // 查询当前剩余堆内存大小
        LOG("Historical minimum remaining memory size: %d bytes.\r\n\r\n", xPortGetMinimumEverFreeHeapSize()); // 查询历史剩余最小内存大小

        /* 查询任务历史剩余最小内存  */
        val = uxTaskGetStackHighWaterMark(taskHandleA);
        LOG("Minimum historical remaining memory for the task: %d bytes\r\n ", (int)val * 4);

        vTaskDelay(1000);
    }

    vTaskDelete(NULL);
}

void freertos_task_init(void)
{

    BaseType_t ret;
    ret = xTaskCreate(taskFunctionA,
                      "taskA",
                      256,
                      NULL,
                      osPriorityNormal,
                      &taskHandleA);

    if (ret != pdPASS)
    {
        LOG("xTaskCreate task A failed! \r\n");
        return;
    }

    ret = xTaskCreate(showTaskInformation,
                      "printTask",
                      256,
                      NULL,
                      osPriorityNormal,
                      &printTaskHandle);

    if (ret != pdPASS)
    {
        LOG("xTaskCreate printTask failed! \r\n");
        return;
    }
    return;
}
