import argparse
import hashlib
import os
import sys


CHUNK_SIZE = 1024 * 1024


def md5_file_hex(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(CHUNK_SIZE), b""):
            h.update(chunk)
    return h.hexdigest()


def md5_file_bytes(path: str) -> bytes:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(CHUNK_SIZE), b""):
            h.update(chunk)
    return h.digest()


def md5_text(text: str) -> str:
    return hashlib.md5(text.encode("utf-8")).hexdigest()


def md5_stdin(binary: bool = False) -> str:
    if binary:
        data = sys.stdin.buffer.read()
    else:
        data = sys.stdin.read().encode("utf-8")
    return hashlib.md5(data).hexdigest()


def copy_stream(src_path: str, dst_path: str) -> None:
    with open(src_path, "rb") as src, open(dst_path, "wb") as dst:
        for chunk in iter(lambda: src.read(CHUNK_SIZE), b""):
            dst.write(chunk)


def append_md5_to_file(src_path: str, out_path: str, fmt: str) -> str:
    if fmt not in {"raw", "hex", "sidecar"}:
        raise ValueError("fmt must be one of: raw, hex, sidecar")

    if fmt == "sidecar":
        digest_hex = md5_file_hex(src_path)
        if not out_path:
            out_path = src_path + ".md5"
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(digest_hex)
        return out_path

    digest_bytes = md5_file_bytes(src_path)
    digest_hex = digest_bytes.hex()

    if not out_path:
        out_path = src_path + (".md5.bin" if fmt == "raw" else ".md5hex.bin")

    if os.path.abspath(out_path) == os.path.abspath(src_path):
        mode = "ab"
        with open(out_path, mode) as f:
            if fmt == "raw":
                f.write(digest_bytes)
            else:
                f.write(digest_hex.encode("ascii"))
        return out_path

    copy_stream(src_path, out_path)
    with open(out_path, "ab") as f:
        if fmt == "raw":
            f.write(digest_bytes)
        else:
            f.write(digest_hex.encode("ascii"))
    return out_path


def _is_hex_bytes(b: bytes) -> bool:
    if len(b) != 32:
        return False
    for c in b:
        if not (48 <= c <= 57 or 65 <= c <= 70 or 97 <= c <= 102):
            return False
    return True


def verify_appended_md5(path: str, fmt: str = "auto") -> bool:
    size = os.path.getsize(path)
    if size < 16:
        print("Error: file too small to contain MD5", file=sys.stderr)
        return False

    with open(path, "rb") as f:
        if fmt in ("auto", "hex") and size >= 32:
            f.seek(-32, os.SEEK_END)
            last32 = f.read(32)
            if fmt == "hex" or _is_hex_bytes(last32):
                payload_len = size - 32
                h = hashlib.md5()
                f.seek(0)
                remaining = payload_len
                while remaining > 0:
                    to_read = min(CHUNK_SIZE, remaining)
                    chunk = f.read(to_read)
                    if not chunk:
                        break
                    h.update(chunk)
                    remaining -= len(chunk)
                expected_hex = last32.decode("ascii")
                return h.hexdigest().lower() == expected_hex.lower()

        f.seek(-16, os.SEEK_END)
        last16 = f.read(16)
        payload_len = size - 16
        h = hashlib.md5()
        f.seek(0)
        remaining = payload_len
        while remaining > 0:
            to_read = min(CHUNK_SIZE, remaining)
            chunk = f.read(to_read)
            if not chunk:
                break
            h.update(chunk)
            remaining -= len(chunk)
        return h.digest() == last16


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "MD5 tools: append MD5 to a file (raw/hex/sidecar), verify appended MD5, "
            "or compute MD5 for files/text/stdin."
        )
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_append = sub.add_parser("append", help="Append MD5 to a file or write sidecar")
    p_append.add_argument("src", help="Source file path (e.g., .bin)")
    p_append.add_argument("-o", "--out", help="Output file path (default: based on src)")
    p_append.add_argument(
        "--format",
        choices=["raw", "hex", "sidecar"],
        default="raw",
        help="raw: 16-byte digest appended; hex: 32 ASCII hex appended; sidecar: write <src>.md5",
    )

    p_verify = sub.add_parser("verify", help="Verify a file with appended MD5")
    p_verify.add_argument("path", help="File path with appended MD5")
    p_verify.add_argument(
        "--format",
        choices=["auto", "raw", "hex"],
        default="auto",
        help="Verification mode: auto-detect, or force raw/hex",
    )

    p_hash = sub.add_parser("hash", help="Compute MD5 for files/text/stdin")
    p_hash.add_argument("files", nargs="*", help="File paths to hash")
    g = p_hash.add_mutually_exclusive_group()
    g.add_argument("-t", "--text", help="Text (UTF-8) to hash")
    g.add_argument("-i", "--stdin", action="store_true", help="Read from stdin")
    p_hash.add_argument(
        "--binary-stdin",
        action="store_true",
        help="Treat stdin as binary data",
    )
    p_hash.add_argument(
        "-r",
        "--raw",
        action="store_true",
        help="Only output the MD5 hex string",
    )

    args = parser.parse_args()

    if args.cmd == "append":
        try:
            out = append_md5_to_file(args.src, args.out, args.format)
            print(out)
        except FileNotFoundError:
            print(f"Error: file not found: {args.src}", file=sys.stderr)
            sys.exit(1)
        except PermissionError:
            print(f"Error: permission denied: {args.src}", file=sys.stderr)
            sys.exit(1)
        except OSError as e:
            print(f"Error: cannot process {args.src}: {e}", file=sys.stderr)
            sys.exit(1)
        return

    if args.cmd == "verify":
        try:
            ok = verify_appended_md5(args.path, args.format)
        except FileNotFoundError:
            print(f"Error: file not found: {args.path}", file=sys.stderr)
            sys.exit(1)
        except PermissionError:
            print(f"Error: permission denied: {args.path}", file=sys.stderr)
            sys.exit(1)
        except OSError as e:
            print(f"Error: cannot read {args.path}: {e}", file=sys.stderr)
            sys.exit(1)
        print("OK" if ok else "FAILED")
        sys.exit(0 if ok else 2)

    if args.cmd == "hash":
        had_any = False
        if args.text is not None:
            had_any = True
            digest = md5_text(args.text)
            print(digest if args.raw else f"{digest}  (text)")
        if args.stdin:
            had_any = True
            digest = md5_stdin(binary=args.binary_stdin)
            print(digest if args.raw else f"{digest}  (stdin)")
        if args.files:
            had_any = True
            for path in args.files:
                try:
                    digest = md5_file_hex(path)
                    print(digest if args.raw else f"{digest}  {path}")
                except FileNotFoundError:
                    print(f"Error: file not found: {path}", file=sys.stderr)
                except PermissionError:
                    print(f"Error: permission denied: {path}", file=sys.stderr)
                except OSError as e:
                    print(f"Error: cannot read {path}: {e}", file=sys.stderr)
        if not had_any:
            print("No input provided. See --help.")
            sys.exit(1)


if __name__ == "__main__":
    main()