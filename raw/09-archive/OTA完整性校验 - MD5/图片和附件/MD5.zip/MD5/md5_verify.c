// Minimal MD5 verification tool for files with appended MD5 (raw/hex)
// Build (MSVC):   cl /O2 md5_verify.c
// Build (MinGW):  gcc -O2 -o md5_verify.exe md5_verify.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>

typedef struct {
    uint32_t state[4];
    uint64_t bitcount;
    unsigned char buffer[64];
} MD5_CTX;

static void md5_transform(uint32_t state[4], const unsigned char block[64]);

static void md5_init(MD5_CTX *ctx) {
    ctx->bitcount = 0;
    ctx->state[0] = 0x67452301U;
    ctx->state[1] = 0xEFCDAB89U;
    ctx->state[2] = 0x98BADCFEU;
    ctx->state[3] = 0x10325476U;
}

static void md5_update(MD5_CTX *ctx, const void *input, size_t len) {
    size_t index = (size_t)((ctx->bitcount / 8) % 64);
    ctx->bitcount += (uint64_t)len * 8;

    size_t partLen = 64 - index;
    const unsigned char *in = (const unsigned char *)input;
    size_t i = 0;

    if (len >= partLen) {
        memcpy(ctx->buffer + index, in, partLen);
        md5_transform(ctx->state, ctx->buffer);
        for (i = partLen; i + 63 < len; i += 64) {
            md5_transform(ctx->state, in + i);
        }
        index = 0;
    }
    memcpy(ctx->buffer + index, in + i, len - i);
}

static void md5_final(unsigned char digest[16], MD5_CTX *ctx) {
    static const unsigned char PADDING[64] = { 0x80 }; // rest zeros
    unsigned char bits[8];

    // Save bitcount in little-endian
    uint64_t bc = ctx->bitcount;
    for (int i = 0; i < 8; ++i) bits[i] = (unsigned char)((bc >> (8 * i)) & 0xFF);

    size_t index = (size_t)((ctx->bitcount / 8) % 64);
    size_t padLen = (index < 56) ? (56 - index) : (120 - index);
    md5_update(ctx, PADDING, padLen);
    md5_update(ctx, bits, 8);

    for (int i = 0; i < 4; ++i) {
        digest[i*4 + 0] = (unsigned char)(ctx->state[i] & 0xFF);
        digest[i*4 + 1] = (unsigned char)((ctx->state[i] >> 8) & 0xFF);
        digest[i*4 + 2] = (unsigned char)((ctx->state[i] >> 16) & 0xFF);
        digest[i*4 + 3] = (unsigned char)((ctx->state[i] >> 24) & 0xFF);
    }
}

#define F(x,y,z) (((x) & (y)) | (~(x) & (z)))
#define G(x,y,z) (((x) & (z)) | ((y) & ~(z)))
#define H(x,y,z) ((x) ^ (y) ^ (z))
#define I(x,y,z) ((y) ^ ((x) | ~(z)))
#define ROTATE_LEFT(x,n) (((x) << (n)) | ((x) >> (32-(n))))
#define FF(a,b,c,d,x,s,ac) { (a) += F((b),(c),(d)) + (x) + (uint32_t)(ac); (a) = ROTATE_LEFT((a),(s)); (a) += (b); }
#define GG(a,b,c,d,x,s,ac) { (a) += G((b),(c),(d)) + (x) + (uint32_t)(ac); (a) = ROTATE_LEFT((a),(s)); (a) += (b); }
#define HH(a,b,c,d,x,s,ac) { (a) += H((b),(c),(d)) + (x) + (uint32_t)(ac); (a) = ROTATE_LEFT((a),(s)); (a) += (b); }
#define II(a,b,c,d,x,s,ac) { (a) += I((b),(c),(d)) + (x) + (uint32_t)(ac); (a) = ROTATE_LEFT((a),(s)); (a) += (b); }

static void md5_transform(uint32_t state[4], const unsigned char block[64]) {
    uint32_t a = state[0], b = state[1], c = state[2], d = state[3];
    uint32_t x[16];
    for (int i = 0; i < 16; ++i) {
        x[i] = (uint32_t)block[i*4] |
               ((uint32_t)block[i*4+1] << 8) |
               ((uint32_t)block[i*4+2] << 16) |
               ((uint32_t)block[i*4+3] << 24);
    }

    // Round 1
    FF(a,b,c,d,x[ 0], 7,0xd76aa478); FF(d,a,b,c,x[ 1],12,0xe8c7b756);
    FF(c,d,a,b,x[ 2],17,0x242070db); FF(b,c,d,a,x[ 3],22,0xc1bdceee);
    FF(a,b,c,d,x[ 4], 7,0xf57c0faf); FF(d,a,b,c,x[ 5],12,0x4787c62a);
    FF(c,d,a,b,x[ 6],17,0xa8304613); FF(b,c,d,a,x[ 7],22,0xfd469501);
    FF(a,b,c,d,x[ 8], 7,0x698098d8); FF(d,a,b,c,x[ 9],12,0x8b44f7af);
    FF(c,d,a,b,x[10],17,0xffff5bb1); FF(b,c,d,a,x[11],22,0x895cd7be);
    FF(a,b,c,d,x[12], 7,0x6b901122); FF(d,a,b,c,x[13],12,0xfd987193);
    FF(c,d,a,b,x[14],17,0xa679438e); FF(b,c,d,a,x[15],22,0x49b40821);

    // Round 2
    GG(a,b,c,d,x[ 1], 5,0xf61e2562); GG(d,a,b,c,x[ 6], 9,0xc040b340);
    GG(c,d,a,b,x[11],14,0x265e5a51); GG(b,c,d,a,x[ 0],20,0xe9b6c7aa);
    GG(a,b,c,d,x[ 5], 5,0xd62f105d); GG(d,a,b,c,x[10], 9,0x02441453);
    GG(c,d,a,b,x[15],14,0xd8a1e681); GG(b,c,d,a,x[ 4],20,0xe7d3fbc8);
    GG(a,b,c,d,x[ 9], 5,0x21e1cde6); GG(d,a,b,c,x[14], 9,0xc33707d6);
    GG(c,d,a,b,x[ 3],14,0xf4d50d87); GG(b,c,d,a,x[ 8],20,0x455a14ed);
    GG(a,b,c,d,x[13], 5,0xa9e3e905); GG(d,a,b,c,x[ 2], 9,0xfcefa3f8);
    GG(c,d,a,b,x[ 7],14,0x676f02d9); GG(b,c,d,a,x[12],20,0x8d2a4c8a);

    // Round 3
    HH(a,b,c,d,x[ 5], 4,0xfffa3942); HH(d,a,b,c,x[ 8],11,0x8771f681);
    HH(c,d,a,b,x[11],16,0x6d9d6122); HH(b,c,d,a,x[14],23,0xfde5380c);
    HH(a,b,c,d,x[ 1], 4,0xa4beea44); HH(d,a,b,c,x[ 4],11,0x4bdecfa9);
    HH(c,d,a,b,x[ 7],16,0xf6bb4b60); HH(b,c,d,a,x[10],23,0xbebfbc70);
    HH(a,b,c,d,x[13], 4,0x289b7ec6); HH(d,a,b,c,x[ 0],11,0xeaa127fa);
    HH(c,d,a,b,x[ 3],16,0xd4ef3085); HH(b,c,d,a,x[ 6],23,0x04881d05);
    HH(a,b,c,d,x[ 9], 4,0xd9d4d039); HH(d,a,b,c,x[12],11,0xe6db99e5);
    HH(c,d,a,b,x[15],16,0x1fa27cf8); HH(b,c,d,a,x[ 2],23,0xc4ac5665);

    // Round 4
    II(a,b,c,d,x[ 0], 6,0xf4292244); II(d,a,b,c,x[ 7],10,0x432aff97);
    II(c,d,a,b,x[14],15,0xab9423a7); II(b,c,d,a,x[ 5],21,0xfc93a039);
    II(a,b,c,d,x[12], 6,0x655b59c3); II(d,a,b,c,x[ 3],10,0x8f0ccc92);
    II(c,d,a,b,x[10],15,0xffeff47d); II(b,c,d,a,x[ 1],21,0x85845dd1);
    II(a,b,c,d,x[ 8], 6,0x6fa87e4f); II(d,a,b,c,x[15],10,0xfe2ce6e0);
    II(c,d,a,b,x[ 6],15,0xa3014314); II(b,c,d,a,x[13],21,0x4e0811a1);
    II(a,b,c,d,x[ 4], 6,0xf7537e82); II(d,a,b,c,x[11],10,0xbd3af235);
    II(c,d,a,b,x[ 2],15,0x2ad7d2bb); II(b,c,d,a,x[ 9],21,0xeb86d391);

    state[0] += a; state[1] += b; state[2] += c; state[3] += d;
}

static void digest_to_hex(const unsigned char d[16], char hex[33]) {
    static const char *tbl = "0123456789abcdef";
    for (int i = 0; i < 16; ++i) {
        hex[i*2]   = tbl[(d[i] >> 4) & 0xF];
        hex[i*2+1] = tbl[d[i] & 0xF];
    }
    hex[32] = '\0';
}

static int is_ascii_hex32(const unsigned char *buf) {
    for (int i = 0; i < 32; ++i) {
        unsigned char c = buf[i];
        if (!((c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F')))
            return 0;
    }
    return 1;
}

#define CHUNK (1024 * 1024)

static long long file_size(FILE *fp) {
#if defined(_WIN32)
    if (_fseeki64(fp, 0, SEEK_END) != 0) return -1;
    long long sz = _ftelli64(fp);
    if (_fseeki64(fp, 0, SEEK_SET) != 0) return -1;
    return sz;
#else
    if (fseeko(fp, 0, SEEK_END) != 0) return -1;
    off_t sz = ftello(fp);
    if (fseeko(fp, 0, SEEK_SET) != 0) return -1;
    return (long long)sz;
#endif
}

static int compute_md5_first_n(FILE *fp, long long n, unsigned char out[16]) {
    MD5_CTX ctx; md5_init(&ctx);
#if defined(_WIN32)
    if (_fseeki64(fp, 0, SEEK_SET) != 0) return 0;
#else
    if (fseeko(fp, 0, SEEK_SET) != 0) return 0;
#endif
    unsigned char *buf = (unsigned char*)malloc(CHUNK);
    if (!buf) return 0;
    long long remaining = n;
    while (remaining > 0) {
        size_t to_read = (size_t)((remaining > CHUNK) ? CHUNK : remaining);
        size_t got = fread(buf, 1, to_read, fp);
        if (got == 0) { free(buf); return 0; }
        md5_update(&ctx, buf, got);
        remaining -= (long long)got;
        if ((long long)got < (long long)to_read) break;
    }
    free(buf);
    md5_final(out, &ctx);
    return 1;
}

static int verify_hex(FILE *fp, long long total) {
    unsigned char tail[32];
#if defined(_WIN32)
    if (_fseeki64(fp, total - 32, SEEK_SET) != 0) return 0;
#else
    if (fseeko(fp, total - 32, SEEK_SET) != 0) return 0;
#endif
    if (fread(tail, 1, 32, fp) != 32) return 0;
    if (!is_ascii_hex32(tail)) return 0;
    long long payload = total - 32;
    unsigned char digest[16];
    if (!compute_md5_first_n(fp, payload, digest)) return 0;
    char hex[33]; digest_to_hex(digest, hex);
    for (int i = 0; i < 32; ++i) {
        char a = hex[i];
        char b = (char)tolower((int)tail[i]);
        if (a != b) return 0;
    }
    return 1;
}

static int verify_raw(FILE *fp, long long total) {
    if (total < 16) return 0;
    unsigned char tail[16];
#if defined(_WIN32)
    if (_fseeki64(fp, total - 16, SEEK_SET) != 0) return 0;
#else
    if (fseeko(fp, total - 16, SEEK_SET) != 0) return 0;
#endif
    if (fread(tail, 1, 16, fp) != 16) return 0;
    long long payload = total - 16;
    unsigned char digest[16];
    if (!compute_md5_first_n(fp, payload, digest)) return 0;
    return memcmp(digest, tail, 16) == 0;
}

int main(int argc, char **argv) {
    const char *format = "auto"; // auto|hex|raw
    const char *path = NULL;
    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--format") == 0 && i + 1 < argc) {
            format = argv[++i];
        } else if (argv[i][0] == '-') {
            fprintf(stderr, "Unknown option: %s\n", argv[i]);
            return 1;
        } else {
            path = argv[i];
        }
    }
    if (!path) {
        fprintf(stderr, "Usage: %s <file> [--format auto|raw|hex]\n", argv[0]);
        return 1;
    }

    FILE *fp = fopen(path, "rb");
    if (!fp) {
        fprintf(stderr, "Error: cannot open %s\n", path);
        return 1;
    }
    long long total = file_size(fp);
    if (total < 0) { fclose(fp); fprintf(stderr, "Error: cannot stat file\n"); return 1; }
    if (total < 16) { fclose(fp); fprintf(stderr, "Error: file too small\n"); return 2; }

    int ok = 0;
    if (strcmp(format, "hex") == 0) {
        ok = (total >= 32) ? verify_hex(fp, total) : 0;
    } else if (strcmp(format, "raw") == 0) {
        ok = verify_raw(fp, total);
    } else { // auto
        ok = (total >= 32 && verify_hex(fp, total)) ? 1 : verify_raw(fp, total);
    }

    fclose(fp);
    if (ok) {
        puts("OK");
        return 0;
    } else {
        puts("FAILED");
        return 2;
    }
}